HW3 Graham Seamans

I did the assignment! It went really well and there were no problems.
The code works by:

- Parsing the arguments to figure out what type of chord to make.
- It then figures out what the base frequency is in a dict.
- Then looks up the other frequencies for the chords.
- Then it generates 3 sine waves, one for each frequency.
- Then it sums them together.

Dependencies (python packages): argparse, numpy, soundfile

To run: `python3 chord.py <base_note_is_minor> <just_or_equal>`
